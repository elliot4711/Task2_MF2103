#include "controller.h"

int32_t Controller_PIController(const int32_t* ref, const int32_t* meas, const uint32_t* ms)
{
  return 0;
}

void Controller_Reset(void)
{
  return;
}
